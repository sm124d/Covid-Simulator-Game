import java.applet.Applet;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class decisionApplet extends Applet implements ActionListener {


    //Declare three new buttons
    Button button1;
    Button button2;
    Button button3;
    //Keep tracks of active button
    boolean button1Active = false;
    boolean button2Active = false;
    boolean button3Active = false;
    //keeps track of risk
    int risk = 0;
    //Keeps track of the image and message to be displayed
    Image image;
    String printMessage;

    int currentBubbleID;

    boolean hasProgramStarted = false;

    Font f1;

    public void init() {
        setBackground(Color.white);

        //Turn Layout manager off
        setLayout(null);

        button1 = new Button("Start");
        button1Active = true;
        add(button1);
        button1.setBounds(400-100,300-40,200,80);
        button1.setBackground(Color.white);
        button1.setForeground(Color.black);
        button1.addActionListener(this);
        f1 = new Font("Arial",Font.PLAIN,32);

    }

    public void addButtons (String choice1, String choice2, String choice3){
        removeButtons();
        button1 = new Button(choice1);
        button2 = new Button(choice2);
        button3 = new Button(choice3);
        button1Active = true;
        button2Active = true;
        button3Active = true;
        add(button1);
        add(button2);
        add(button3);
        button1.setBounds(650-100,160,200,100);
        button2.setBounds(400-100,160,200,100);
        button3.setBounds(150-100,160,200,100);
        button1.setBackground(Color.white);
        button2.setBackground(Color.white);
        button3.setBackground(Color.white);
        button1.setForeground(Color.black);
        button2.setForeground(Color.black);
        button3.setForeground(Color.black);
        button1.addActionListener(this);
        button2.addActionListener(this);
        button3.addActionListener(this);
    }


    public void addButtons (String choice1, String choice2){
        removeButtons();
        button1 = new Button(choice1);
        button2 = new Button(choice2);
        button1Active = true;
        button2Active = true;
        add(button1);
        add(button2);
        button1.setBounds(525-100,160,200,100);
        button2.setBounds(275-100,160,200,100);
        button1.setBackground(Color.white);
        button2.setBackground(Color.white);
        button1.setForeground(Color.black);
        button2.setForeground(Color.black);
        button1.addActionListener(this);
        button2.addActionListener(this);
    }

    public void addButtons (String choice1){
        removeButtons();
        button1 = new Button(choice1);
        button1Active = true;
        add(button1);
        button1.setBounds(400-100,160,200,100);
        button1.setBackground(Color.white);
        button1.setForeground(Color.black);
        button1.addActionListener(this);
    }


    public void removeButtons(){
        if (button1Active){
            remove(button1);
        }
        if (button2Active){
            remove(button2);
        }
        if (button3Active){
            remove(button3);
        }
    }


    public void display (int id) {
        if (id == 0) {
//            wake up
            addButtons("Hang out with family", "Hang out with friends", "Go to your computer");
            image = getImage(getDocumentBase(), "Wake up.jpg");
            printMessage = "Wake up";
        } else if (id == 1) {
//            Hang out with family
            risk += 1;
            addButtons("Go shopping", "Go on a walk in the park", "Go to a large gathering");
            image = getImage(getDocumentBase(), "Family.jpg");
            printMessage = "You decide to go out with your family.";
        }
        else if (id == 23) {
//            Take a walk
            risk += 1;
            addButtons("Go back home", "Go shopping", "Go to a large gathering");
            image = getImage(getDocumentBase(), "Park.jpg");
            printMessage = "You take a nice walk with your family";
        }
        else if (id == 24) {
//            Go to a large Gathering
            risk += 1;
            addButtons("Go to a large pool party", "Go to a smaller gathering");
            image = getImage(getDocumentBase(), "Party.jpg");
            printMessage = "You were invited to two parties.";
        }
        else if (id == 34) {
//            Large Party
            risk += 5;
            addButtons("Go home");
            image = getImage(getDocumentBase(), "PoolParty.jpg");
            printMessage = "You feel tired after the party. You decide to head home.";
        }
        else if (id == 35) {
//            Small Party
            risk += 2;
            addButtons("Go home");
            image = getImage(getDocumentBase(), "SmallParty.jpg");
            printMessage = "You feel tired after the party. You decide to head home.";
        }
        else if (id == 22){
//            Go shopping
            risk += 2;
            addButtons("Go into a small store", "Go into large popular store");
            image = getImage(getDocumentBase(), "Mall.jpg");
            printMessage = "After arriving at the shopping center, you see a large crowd of people lining up to get the new phone that just released. " +
                    "Although you want to check it out, it may be dangerous.";
        }
        else if (id == 25) {
//            Go to the small store
            risk += 1;
            addButtons("Continue Shopping", "Go back home");
            image = getImage(getDocumentBase(), "Small store.jpg");
            printMessage = "You decided to go to the smaller, but safer store.";
        }
        else if (id == 26) {
//            Go to the large store
            risk += 3;
            addButtons("Continue Shopping", "Go back home");
            image = getImage(getDocumentBase(), "BigShop.jpg");
            printMessage = "Although it may be dangerous, you have been wanting to see the new phone.";
        }
        else if (id == 27) {
//           Come back from hanging out with family for friends
            risk += 0;
            addButtons("Play video games", "Watch videos on Youtube", "Do summer homework");
            image = getImage(getDocumentBase(), "ComingBack.png");
            printMessage = "It has been a long day and you decide to go home and just use your computer.";
        }
        else if (id == 28) {
//           Continue Shopping
            risk += 3;
            addButtons("Go home");
            image = getImage(getDocumentBase(), "Mall.jpg");
            printMessage = "You decide to keep shopping, not because it's safer, but because its fun.";
        }
        else if (id == 2) {
//            Hang out with friends
            risk += 3;
            addButtons("Play sports", "Study in the library");
            image = getImage(getDocumentBase(), "Friends.jpg");
            printMessage = "Hang out with friends.";
        }
        else if (id == 29) {
//            Play Sports
            risk += 3;
            addButtons("Play tackle football", "Play tennis");
            image = getImage(getDocumentBase(), "Sports.jpg");
            printMessage = "The group takes a vote on what to do and you are the tie breaker.";
        }
        else if (id == 31) {
//            Playing tackle football
            risk += 5;
            addButtons("Go home");
            image = getImage(getDocumentBase(), "Football.png");
            printMessage = "You and your friends are too tired to continue after a few hours. You decide to head home.";
        }
        else if (id == 31) {
//            Playing tennis
            risk += 3;
            addButtons("Go home");
            image = getImage(getDocumentBase(), "Tennis.png");
            printMessage = "You and your friends are too tired to continue after a few hours. You decide to head home.";
        }
        else if (id == 30) {
//            Study in the library
            risk += 3;
            addButtons("Go home", "Hang out with your family");
            image = getImage(getDocumentBase(), "Library.jpg");
            printMessage = "After all that studying, you feel prepared for the test tomorrow.";
        }

        else if (id == 3) {
//            Use your computer
            risk += 0;
            addButtons("Play video games", "Watch videos on Youtube", "Do summer homework");
            image = getImage(getDocumentBase(), "Computer.jpg");
            printMessage = "After slowly waking yourself up, you walk over to your computer.";
        } else if (id == 4) {
//       Play video games
            risk += 0;
            addButtons("Eat breakfast", "Ignore your mom");
            image = getImage(getDocumentBase(), "Mom.jpg");
            printMessage = "Your mom calls for you to eat breakfast.";
        }
        else if (id == 5) {
//       Watch videos on Youtube
            risk += 0;
            addButtons("Eat breakfast", "Ignore your mom");
            image = getImage(getDocumentBase(), "Youtube.jpg");
            printMessage = "Your mom calls for you to eat breakfast.";
        }
        else if (id == 6) {
//       Do summer math
            risk += 0;
            addButtons("Eat breakfast", "Ignore your mom");
            image = getImage(getDocumentBase(), "Summer Work.png");
            printMessage = "Your mom calls for you to eat breakfast.";
        }
        else if (id == 7) {
//            Eating Breakfast
            risk += 0;
            addButtons("Hang out with family", "Hang out with friends", "Go to your computer");
            image = getImage(getDocumentBase(), "Breakfast.jpg");
            printMessage = "You come downstairs to the smell of freshly cooked bacon." +
                    "You are happy you came downstairs.";
        }
        else if (id == 8) {
//            Mom yells at you
            risk += 0;
            addButtons("Go downstairs");
            image = getImage(getDocumentBase(), "Mom.jpg");
            printMessage = "Your Mom yells at you and makes you eat breakfast.";
        }
        else if (id == 9) {
            risk += 0;
            addButtons("Play video games", "Watch videos on Youtube", "Do summer homework");
            image = getImage(getDocumentBase(), "Computer.jpg");
            printMessage = "After breakfast you decide to come back upstairs to use your computer.";
        }
        else if (id == 10) {
//       Play video games (Lunch version)
            risk += 0;
            addButtons("Eat Lunch", "Ignore your mom");
            image = getImage(getDocumentBase(), "Video Games.jpg");
            printMessage = "Your mom calls for you to eat lunch.";
        }
        else if (id == 11) {
//       Watch videos on Youtube (Lunch version)
            risk += 0;
            addButtons("Eat Lunch", "Ignore your mom");
            image = getImage(getDocumentBase(), "Youtube.jpg");
            printMessage = "Your mom calls for you to eat lunch.";
        }
        else if (id == 12) {
//       Do summer homework (Lunch version)
            risk += 0;
            addButtons("Eat Lunch", "Ignore your mom");
            image = getImage(getDocumentBase(), "Summer Work.jpg");
            printMessage = "Your mom calls for you to eat lunch.";
        }
        else if (id == 14) {
//            Ignore your mom (Lunch Version)
            risk += 0;
            addButtons("Go downstairs");
            image = getImage(getDocumentBase(), "Mom.jpg");
            printMessage = "Your mom yells at you and makes you eat lunch.";
        }
        else if (id == 13) {
//            Eat Lunch (Lunch Version)
            risk += 0;
            addButtons("Play Video Games,", "Watch Youtube", "Do Summer work");
            image = getImage(getDocumentBase(), "Lunch.jpg");
            printMessage = "You eat lunch.";
        }
        else if (id == 15) {
//       Play video games (Dinner version)
            risk += 0;
            addButtons("Eat dinner", "Ignore your mom");
            image = getImage(getDocumentBase(), "Mom.jpg");
            printMessage = "Your mom calls for you to eat dinner.";
        }
        else if (id == 16) {
//       Watch videos on Youtube (Dinner version)
            risk += 0;
            addButtons("Eat dinner", "Ignore your mom");
            image = getImage(getDocumentBase(), "Mom.jpg");
            printMessage = "Your mom calls for you to eat dinner.";
        }
        else if (id == 17) {
//       Do summer homework (Dinner version)
            risk += 0;
            addButtons("Eat dinner", "Ignore your mom");
            image = getImage(getDocumentBase(), "Mom.jpg");
            printMessage = "Your mom calls for you to eat dinner.";
        }
        else if (id == 19) {
//            Eat Dinner (Low Risk Ending)
            risk += 0;
            addButtons("Go to bed");
            image = getImage(getDocumentBase(), "Dinner.jpg");
            printMessage = "You feel tired after all that you did today.";
        }
        else if (id == 20) {
//            Ignore your mom (Dinner Version)
            risk += 0;
            addButtons("Go downstairs");
            image = getImage(getDocumentBase(), "Mom.jpg");
            printMessage = "Your mom yells at you and makes you eat dinner.";
        }
        else if (id == 33) {
//            Display Results
            removeButtons();
            if (risk >= 0 && risk < 5) {
                printMessage = "You took some of the safest routes you could today. " +
                        "You have a very low chance of getting sick.";
            } else if(risk >= 5 && risk < 10) {
                printMessage = "You had a very good balance between being safe, and enjoying life " +
                        "You have a medium chance of getting sick.";
            } else if(risk >= 10) {
                printMessage = "You went through today making some very risky and bad choices. " +
                        "You have a very high chance of getting sick.";
            }
        }

        else if (id == 21){
            image = getImage(getDocumentBase(), "Sleep.jpg");
            printMessage = "You slowly fall asleep.";
            addButtons("Show your results");
        }

        repaint();
    }

    public int findNextAction (int currentID, int choice){
        if (currentID == 0 && choice == 1){
            return 1;
        }
        else if (currentID == 1 && choice == 1){
            return 22;
        }
        else if (currentID == 22 && choice == 1 ){
            return 25;
        }
        else if (currentID == 22 && choice == 2){
            return 26;
        }
        else if (currentID == 25 && choice == 1){
            return 28;
        }
        else if (currentID == 28 && choice == 1){
            return 27;
        }
        else if (currentID == 25 && choice == 2){
            return 27;
        }
        else if (currentID == 27 && choice == 1){
            return 15;
        }
        else if (currentID == 27 && choice == 2){
            return 16;
        }
        else if (currentID == 27 && choice == 3){
            return 17;
        }
        else if (currentID == 1 && choice == 2){
            return 23;
        }
        else if (currentID == 23 && choice == 1){
            return 27;
        }
        else if (currentID == 23 && choice == 2){
            return 22;
        }
        else if (currentID == 23 && choice == 3){
            return 24;
        }
        else if (currentID == 24 && choice == 1){
            return 34;
        }
        else if (currentID == 24 && choice == 2){
            return 35;
        }
        else if (currentID == 34 && choice == 1){
            return 27;
        }
        else if (currentID == 35 && choice == 1){
            return 27;
        }
        else if (currentID == 0 && choice == 2){
            return 2;
        }
        else if (currentID == 2 && choice == 1){
            return 29;
        }
        else if (currentID == 29 && choice == 1){
            return 31;
        }
        else if (currentID == 29 && choice == 2) {
            return 32;
        }
        else if (currentID == 31 && choice == 1) {
            return 27;
        }
        else if (currentID == 32 && choice == 1) {
            return 27;
        }
        else if (currentID == 2 && choice == 2) {
            return 30;
        }
        else if (currentID == 30 && choice == 1) {
            return 27;
        }
        else if (currentID == 30 && choice == 2) {
            return 1;
        }
        else if (currentID == 0 && choice == 3){
            return 3;
        }
        else if (currentID == 3 && choice == 1){
            return 4;
        }
        else if (currentID == 3 && choice == 2){
            return 5;
        }
        else if (currentID == 3 && choice == 3){
            return 6;
        }
        else if (currentID == 4 && choice == 1){
            return 7;
        }
        else if (currentID == 5 && choice == 1){
            return 7;
        }
        else if (currentID == 6 && choice == 1){
            return 7;
        }
        else if (currentID == 4 && choice == 2){
            return 8;
        }
        else if (currentID == 5 && choice == 2){
            return 7;
        }
        else if (currentID == 6 && choice == 2){
            return 7;
        }
        else if (currentID == 7 && choice == 1){
            return 1;
        }
        else if (currentID == 7 && choice == 2){
            return 2;
        }
        else if (currentID == 7 && choice == 3){
            return 9;
        }
        else if (currentID == 8 && choice == 1){
            return 7;
        }
        else if (currentID == 9 && choice == 1){
            return 10;
        }
        else if (currentID == 9 && choice == 2){
            return 11;
        }
        else if (currentID == 9 && choice == 3){
            return 12;
        }
        else if (currentID == 10 && choice == 1){
            return 13;
        }
        else if (currentID == 10 && choice == 2){
            return 14;
        }
        else if (currentID == 11 && choice == 1){
            return 13;
        }
        else if (currentID == 11 && choice == 2){
            return 14;
        }
        else if (currentID == 12 && choice == 1){
            return 13;
        }
        else if (currentID == 12 && choice == 2){
            return 14;
        }
        else if (currentID == 14 && choice == 1){
            return 13;
        }
        else if (currentID == 13 && choice == 1){
            return 15;
        }
        else if (currentID == 13 && choice == 2){
            return 16;
        }
        else if (currentID == 13 && choice == 3){
            return 17;
        }
        else if (currentID == 15 && choice == 1){
            return 19;
        }
        else if (currentID == 15 && choice == 2){
            return 20;
        }
        else if (currentID == 16 && choice == 1){
            return 19;
        }
        else if (currentID == 16 && choice == 2){
            return 20;
        }
        else if (currentID == 17 && choice == 1){
            return 19;
        }
        else if (currentID == 17 && choice == 2){
            return 20;
        }
        else if (currentID == 19 && choice == 1){
            return 21;
        }
        else if (currentID == 21 && choice == 1){
            return 33;
        }
        else if (currentID == 20 && choice == 1){
            return 19;
        }
        else if (currentID == 29 && choice == 2){
            return 31;
        }
        else if (currentID == 1 && choice == 3){
            return 24;
        }







        printMessage = "error";
        repaint();
        return -1;
    }

    public void actionPerformed(ActionEvent ae) {
        Object buttonPressed = ae.getSource();
        if (!hasProgramStarted){
            if (buttonPressed == button1) {
                hasProgramStarted = true;
                remove(button1);
                button1Active = false;
                currentBubbleID = 0;
                display(currentBubbleID);
            }
        }
        else {
            int choice = -1;
            if (buttonPressed == button1) {
                choice = 1;
            } else if (buttonPressed == button2) {
                choice = 2;
            }
            else if (buttonPressed == button3) {
                choice = 3;
            }
            currentBubbleID = findNextAction(currentBubbleID,choice);
            display(currentBubbleID);
        }
    }

    public int returnStart (String message, int middleCordinate){
        //takes a message and the desired location of the center and returns where the message should start
        //** g.drawString coordinates are where the message starts
        return (middleCordinate - (message.length())*7);
    }

    public int findY (int imageHeight, int posY) {
        return posY - imageHeight / 2;
    }

    public int findX (int imageWidth, int posX){
        return posX - imageWidth/2;
    }



    public void paint(Graphics g){
        g.setFont(f1);
        if (printMessage.length() > 58){
            String line1 = "";
            String line2 = "";
            String line3 = "";
            for (int i = 28; i>0; i--){
                if (printMessage.charAt(i) == ' '){
                    line1 = printMessage.substring(0,i);
                    break;
                }
            }
            for (int i = 58; i>0; i--){
                if (printMessage.charAt(i) == ' '){
                    line2 = printMessage.substring(line1.length(),i);
                    line3 = printMessage.substring(i+1,printMessage.length());
                    break;
                }
            }
            g.drawString(line1,returnStart(line1,400),75);
            g.drawString(line2,returnStart(line2,400),100);
            g.drawString(line3,returnStart(line3,400),125);

        }
        else if (printMessage.length() > 25){
            String line1 = "";
            String line2 = "";
            for (int i = 25; i>0; i--){
                if (printMessage.charAt(i) == ' '){
                    line1 = printMessage.substring(0,i);
                    line2 = printMessage.substring(i+1,printMessage.length());
                    break;
                }
            }
            g.drawString(line1,returnStart(line1,400),75);
            g.drawString(line2,returnStart(line2,400),100);
        }
        else{
            g.drawString(printMessage,returnStart(printMessage,400),75);
        }


        g.drawImage(image, findX(image.getWidth(null), 400), findY(image.getHeight(null), 450), this);
    }

}




